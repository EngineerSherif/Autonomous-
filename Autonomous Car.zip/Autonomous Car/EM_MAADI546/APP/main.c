#include "../LIB/BIT_MATH.h"
#include "../LIB/STD_TYPE.h"
#include "../LIB/interrupt_vector.h"
#include "../MCAL/TIM0/TIM0_interface.h"
#include "../MCAL/TIM1/TIM1_interface.h"
#include "../MCAL/TIM2/TIM2_interface.h"
#include "../MCAL/DIO/DIO_interface.h"
#include "../MCAL/EXTI/EXTI_interface.h"
#include "../MCAL/GI/GI_interface.h"
#include "../MCAL/ADC/ADC_interface.h"
#include "../MCAL/WDT/WDT_interface.h"
#include "../MCAL/UART/UART_interface.h"
#include "../MCAL/SPI/SPI_interface.h"
#include "../MCAL/TWI/TWI_interface.h"
#include "../HAL/LCD/LCD_config.h"
#include "../HAL/LCD/LCD_interface.h"
#include "../HAL/KEYPAD/KEYPAD_config.h"
#include "../HAL/KEYPAD/KEYPAD_interface.h"
#include "../HAL/DC_Motor/DC_Motor_config.h"
#include "../HAL/DC_Motor/DC_Motor_interface.h"
#include "../HAL/EEPROM_EXTERN/EEPROM_EXTERN_interface.h"
#define F_CPU 16000000UL
#include <util/delay.h>


volatile u16 TIM0_overflowCount = 0;

void overflowHandler(){
	TIM0_overflowCount++;
}

s16 USsensor_s16ReadDistance(){
	s16 distance = 0;
	TIM0_overflowCount = 0;
	DIO_voidSetPinVal(DIO_PORTC, DIO_PIN0, HIGH);
	_delay_us(10);
	DIO_voidSetPinVal(DIO_PORTC, DIO_PIN0, LOW);
	
	while (DIO_u8ReadpinVal(DIO_PORTC, DIO_PIN1) == LOW);
	
	TIM0_voidInitCTC_OV(OV_MODE);
	TIM0_voidSetCallBack(overflowHandler, OV_MODE);
	TIM0_voidReset();
	while (DIO_u8ReadpinVal(DIO_PORTC, DIO_PIN1) == HIGH);
	TIM0_voidStop();
	distance = ((TIM0_overflowCount*256 + TIM0_u16ReadVal())*0.1372)/2 + 1;
	return distance;
}


void LCD_voidReadDistance(s16 pre_distance, s16 distance){
	u8 string1[] = {"Distance= "};
	u8 string2[] = {"Out of Range"};
	
	/* Distance is out of range as ultrasonic sensor's maximum distance is 500 cm */	
	if (distance > 500)
	{
		LCD_voidSendCommand(1);
		LCD_voidSendString(string2);
		pre_distance = 500;
	}
	/* Clears LCD screen from extra digits when going from higher digit order numbers to lower ones */
	if((pre_distance >= 1000 && distance < 1000) || (pre_distance >= 100 && distance < 100) || (pre_distance >= 10 && distance < 10)){
		LCD_voidSendCommand(1);
	}
	/* Read Distance */
	LCD_voidGetXY(0,0);
	LCD_voidSendString(string1);
	LCD_voidGetXY(10, 0);
	LCD_voidReadNumber(distance);
}


u16 Servo_voidGetDirection(){
	s16 pre_distance = 0, distance = 0;
	u8 string3[] = {"Angle= "};
	
	pre_distance = USsensor_s16ReadDistance();
	
	for (u16 angle = 89; angle >= 30; angle--)
	{
		TIM2_voidServoSetDegree(angle);
		_delay_ms(10);
		distance = USsensor_s16ReadDistance();
		
		LCD_voidReadDistance(pre_distance, distance);
		LCD_voidGetXY(0, 1);
		LCD_voidSendString(string3);
		LCD_voidGetXY(7, 1);
		LCD_voidReadNumber((s16)angle);
		
		if ((distance - pre_distance) > 40)
		{
			TIM2_voidServoSetDegree(90);
			return (pre_distance*cos(angle*(22/7)/180));
		}
		pre_distance = distance;
	}
	
	TIM2_voidServoSetDegree(90);
	pre_distance = USsensor_s16ReadDistance();
	
	for (u16 angle = 91; angle <= 150; angle++)
	{
		TIM2_voidServoSetDegree(angle);
		_delay_ms(10);
		distance = USsensor_s16ReadDistance();
		
		LCD_voidReadDistance(pre_distance, distance);
		LCD_voidGetXY(0, 1);
		LCD_voidSendString(string3);
		LCD_voidGetXY(7, 1);
		LCD_voidReadNumber((s16)angle);
		
		if ((distance - pre_distance) > 40)
		{
			TIM2_voidServoSetDegree(90);
			return ((-1)*pre_distance*cos((180-angle)*(22/7)/180));
		}
		pre_distance = distance;
	}
	return 0;
}

void DCMOTOR_voidAcceleration(){
	DCMOTOR_voidForward(40);
	_delay_ms(50);
	DCMOTOR_voidForward(20);
}


int main(void)
{
	/* LCD Initialization*/
	DIO_voidSetPortDir(LCD_CPORT, 0x0e);
	DIO_voidSetPortDir(LCD_DPORT, 0xf0);
	LCD_voidInit();
	
	/* Trigger pin & Echo pin */
	DIO_voidSetPinDir(DIO_PORTC, DIO_PIN0, OUTPUT);
	DIO_voidSetPinDir(DIO_PORTC, DIO_PIN1, INPUT);
	
	/* Servo Pin */
	DIO_voidSetPinDir(DIO_PORTD, DIO_PIN7, OUTPUT);
	TIM2_voidFastPWMinit();
	
	GI_voidEnable();
	
	s16 distance = 0, pre_distance = 1, min_length = 0, forward_time = 0, turnRight_time = 800, turnLeft_time = 600, speed = 39, stuck_check = 0, start_engine = 0;
	//                                                                    Turn right, turn left times, and speed have been calculated by experiment 
	
	
	while(1){
		
		if (start_engine == 0)
		{
			_delay_ms(3000);
			DCMOTOR_voidForward(40);
			_delay_ms(100);
			start_engine++;
		}
		DCMOTOR_voidForward(20);
		
		TIM2_voidServoSetDegree(90);
		distance = USsensor_s16ReadDistance();
		LCD_voidReadDistance(pre_distance, distance);
		
		
		/* Check if car is about to crash or is already stuck and then make it go backwards */
		if (distance <= 15)
		{
			DCMOTOR_voidReverse(40);
			_delay_ms(500);
			DCMOTOR_voidStop();
			DCMOTOR_voidAcceleration();
		}
		if (pre_distance == distance && stuck_check <= 1)
		{
			stuck_check++;
		}
		else if (pre_distance == distance && stuck_check == 2)
		{
			DCMOTOR_voidReverse(40);
			_delay_ms(500);
			DCMOTOR_voidStop();
			DCMOTOR_voidForward(40);
			_delay_ms(50);
			DCMOTOR_voidStop();
			DCMOTOR_voidRight(35);
			_delay_ms(500);
			DCMOTOR_voidStop();
			DCMOTOR_voidAcceleration();
		}
		else{
			stuck_check = 0;
		}
		
		/***********************************************************************************/
		pre_distance = distance;
		
		
	/* Car detects an obstacle, stops, and then try to pass it */
		if (distance < 43 && stuck_check == 0)
		{
			DCMOTOR_voidStop();
			min_length = Servo_voidGetDirection();        //minimum length for the car to go right or left
			
			TIM2_voidInitCTC_OV(CTC_MODE);
			
			if (min_length > 0)
			{
				forward_time = (min_length + 7.5)/speed; //the time it needs to move for this minimum length
				
				DCMOTOR_voidRight(35);               
				TIM2_voidDelayms(turnRight_time);        // Time takes to turn right by 90 degrees
				DCMOTOR_voidStop();
				
				DCMOTOR_voidAcceleration();
				TIM2_voidDelayms(forward_time*1000);
				DCMOTOR_voidStop();
				
				DCMOTOR_voidLeft(35);
				TIM2_voidDelayms(turnLeft_time);		// Time takes to turn left by 90 degrees
				DCMOTOR_voidStop();	
			}
			
			else if (min_length < 0)
			{
				forward_time = ((-1)*min_length + 7.5)/speed; //the time it needs to move for this minimum length
				
				DCMOTOR_voidLeft(35);
				TIM2_voidDelayms(turnLeft_time+200);		 // Time takes to turn left by 90 degrees
				DCMOTOR_voidStop();
				
				DCMOTOR_voidAcceleration();
				TIM2_voidDelayms(forward_time*1000);
				DCMOTOR_voidStop();
				
				DCMOTOR_voidRight(35);
				TIM2_voidDelayms(turnRight_time-200);		// Time takes to turn right by 90 degrees
				DCMOTOR_voidStop();
			}
			
			else{
				DCMOTOR_voidRight(35);
				TIM2_voidDelayms(turnRight_time*2);			// Time takes to turn right by 180 degrees
				DCMOTOR_voidStop();
			}
			
			DCMOTOR_voidAcceleration();
			TIM2_voidFastPWMinit();
			LCD_voidSendCommand(1);
			_delay_ms(200);
		}
	}
}








		
		
		
		
		