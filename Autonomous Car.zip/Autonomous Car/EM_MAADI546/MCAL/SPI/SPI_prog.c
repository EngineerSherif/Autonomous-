#include "../../LIB/BIT_MATH.h"
#include "../../LIB/STD_TYPE.h"
#include "../DIO/DIO_interface.h"
#include "SPI_reg.h"
#include "SPI_interface.h"


void SPIMaster_voidInit(void){
	/* Pin Configuration */
	DIO_voidSetPinDir(SPI_PORT, SS_PIN, OUTPUT); // SS
	DIO_voidSetPinDir(SPI_PORT, MOSI_PIN, OUTPUT); // MOSI
	DIO_voidSetPinDir(SPI_PORT, MISO_PIN, INPUT); // MISO
	DIO_voidSetPinDir(SPI_PORT, SCK_PIN, OUTPUT); // SCK
	
	/* Clock Rate: fosc/128 */
	SET_BIT(SPCR_REG, 1);
	SET_BIT(SPCR_REG, 0);

	/* Master Mode Select */
	SET_BIT(SPCR_REG, 4);
	
	/* Data Order Select: MSB */
	CLR_BIT(SPCR_REG, 5);
	
	/* Clock Polarity: Leading Edge: Rising / Trailing Edge: Falling */
	CLR_BIT(SPCR_REG, 3);
	
	/* Clock Phase: Leading Edge: Sample / Trailing Edge: Setup */
	CLR_BIT(SPCR_REG, 2);
	
    /* SPI Enable */
    SET_BIT(SPCR_REG, 6);
}

void SPISlave_voidInit(void){
	/* Pin Configuration */
	DIO_voidSetPinDir(SPI_PORT, SS_PIN, INPUT); // SS
	DIO_voidSetPinDir(SPI_PORT, MOSI_PIN, INPUT); // MOSI
	DIO_voidSetPinDir(SPI_PORT, MISO_PIN, OUTPUT); // MISO
	DIO_voidSetPinDir(SPI_PORT, SCK_PIN, INPUT); // SCK
	
	/* Slave Mode Select */
	CLR_BIT(SPCR_REG, 4);
	
	/* SPI Enable */
	SET_BIT(SPCR_REG, 6);
	SET_BIT(SPCR_REG, 5);
}

void SPIMaster_voidSendData(u8 copy_u8data){
	SPDR_REG = copy_u8data;
	while(GET_BIT(SPSR_REG, 7) == 0);
}

u8 SPISlave_u8RecieveData(){
	while(GET_BIT(SPSR_REG, 7) == 0);
	return SPDR_REG;
}
