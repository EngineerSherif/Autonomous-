#ifndef SPI_INTERFACE_H_
#define SPI_INTERFACE_H_


#define SPI_PORT   DIO_PORTB
#define SS_PIN     DIO_PIN4
#define MOSI_PIN   DIO_PIN5
#define MISO_PIN   DIO_PIN6
#define SCK_PIN    DIO_PIN7


void SPIMaster_voidInit(void);
void SPISlave_voidInit(void);
void SPIMaster_voidSendData(u8 copy_u8data);
u8 SPISlave_u8RecieveData(void);


#endif /* SPI_INTERFACE_H_ */