#include "../../LIB/BIT_MATH.h" 
#include "../../LIB/STD_TYPE.h"
#include "../../LIB/interrupt_vector.h"
#include "TIM0_reg.h" 
#include "TIM0_interface.h" 

void (*TIM0_PTR[2])(void)={null}; 

void TIM0_voidInitCTC_OV(u8 copy_u8mode){
	
	/*  set prescaler */
	
	TCCR0_REG &= 0b11111000 ;
	TCCR0_REG |= TIM0_PRESCALER ;
	
	if(copy_u8mode == OV_MODE){
		/* select mode : normal mode */
		CLR_BIT(TCCR0_REG,3) ;
		CLR_BIT(TCCR0_REG,6) ;
		
		/*enable  timer0 overflow interrupt */
		SET_BIT(TIMSK_REG,0) ;
	}
	
	else if(copy_u8mode == CTC_MODE){
		/* select mode : CTC mode */
		SET_BIT(TCCR0_REG,3) ;
		CLR_BIT(TCCR0_REG,6) ;
		
		/*enable  timer0 CTC interrupt */
		SET_BIT(TIMSK_REG,1) ;
		
		/* SET OCR VAL */
		OCR0_REG=OCR_VAL ; 
	}
}

void TIM0_voidSetCallBack(void(*ptr)(void), u8 interrupt_mode){
	switch(interrupt_mode){
		case OV_MODE:  TIM0_PTR[0]=ptr;  break;
		case CTC_MODE: TIM0_PTR[1]=ptr;  break;
	}
}

void TIM0_voidFastPWM(u8 copy_u8dc){
	/* select mode : Fast PWM mode */
	SET_BIT(TCCR0_REG, 3);
	SET_BIT(TCCR0_REG, 6);
	
	/*  set prescaler */
	TCCR0_REG &= 0b11111000 ;
	TCCR0_REG |= TIM0_PRESCALER ;
	
	#if FAST_PWM_MODE == NON_INVERTING_MODE
	CLR_BIT(TCCR0_REG, 4);
	SET_BIT(TCCR0_REG, 5);
	#elif FAST_PWM_MODE == INVERTING_MODE
	SET_BIT(TCCR0_REG, 4);
	SET_BIT(TCCR0_REG, 5);
	#endif
	
	OCR0_REG = copy_u8dc * 2.56;
}


void TIM0_voidReset(void){
	
	TCNT0_REG=0x0000 ;
}

void TIM0_voidStop(void){
	TCCR0_REG &= 0;
}

u16 TIM0_u16ReadVal(void){
	
	return TCNT0_REG ;
}

ISR(TIMER0_OVF){
	
	TIM0_PTR[0]();	
}

ISR(TIMER0_COMP){
	
	TIM0_PTR[1]() ;
}