#ifndef TIM0_INTERFACE_H_
#define TIM0_INTERFACE_H_


/* select prescaler */

#define  NO_PRESCALER      0x01
#define  _8_PRESCALER      0x02
#define  _32_PRESCALER     0x03
#define  _64_PRESCALER     0x04
#define  _128_PRESCALER    0x05
#define  _256_PRESCALER    0x06
#define  _1024_PRESCALER   0x07

#define  TIM0_PRESCALER      _32_PRESCALER

/* TIMER MODE */
#define OV_MODE   0
#define CTC_MODE  1

/* OCR VAL */
#define  OCR_VAL   250

/* Fast PWM Mode */
#define INVERTING_MODE       0
#define NON_INVERTING_MODE   1

/* Select Fast PWM Mode */
#define FAST_PWM_MODE   NON_INVERTING_MODE


void TIM0_voidInitCTC_OV(u8 copy_u8mode); 
void TIM0_voidFastPWM(u8 copy_u8dc);
void TIM0_voidSetCallBack(void(*ptr)(void), u8 interrupt_mode);
void TIM0_voidDelayms(u16 delay_ms);
void TIM0_voidReset(void);
void TIM0_voidStop(void);
u16 TIM0_u16ReadVal(void);

#endif /* TIM0_INTERFACE_H_ */