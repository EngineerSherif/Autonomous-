/*
 * TIM2_interface.h
 *
 * Created: 9/13/2024 1:54:13 PM
 *  Author: Sherif
 */ 


#ifndef TIM2_INTERFACE_H_
#define TIM2_INTERFACE_H_


#define  NO_PRESCALER      0x01
#define  _8_PRESCALER      0x02
#define  _32_PRESCALER     0x03
#define  _64_PRESCALER     0x04
#define  _128_PRESCALER    0x05
#define  _256_PRESCALER    0x06
#define  _1024_PRESCALER   0x07

#define  TIM2_PRESCALER      _256_PRESCALER


#define OV_MODE   0
#define CTC_MODE  1


extern volatile u16 TIM2_overflowCount;

void TIM2_voidFastPWMinit();
void TIM2_CTCinit();
void TIM2_voidDelayms(u16 delay_ms);
void TIM2_voidServoSetDegree(u16 copy_u16degree);
void TIM2_voidInitCTC_OV(u8 copy_u8mode);
void TIM2_voidReset(void);
void TIM2_voidStart(void);
s16 TIM2_s16ReadVal(void);




#endif /* TIM2_INTERFACE_H_ */