#include "../../LIB/BIT_MATH.h"
#include "../../LIB/STD_TYPE.h"
#include "TIM2_reg.h"
#include "TIM2_interface.h"

volatile u16 TIM2_overflowCount = 0;


void TIM2_voidFastPWMinit(){
	
	/* Select Fast PWM Mode */
	SET_BIT(TCCR2_REG, 3);
	SET_BIT(TCCR2_REG, 6);
	CLR_BIT(TCCR2_REG, 7);
	
	/* Select Non-inverting Mode */
	CLR_BIT(TCCR2_REG, 4);
	SET_BIT(TCCR2_REG, 5);
	
	/* Select Prescaler */
	TCCR2_REG &= 0b11111000;
	TCCR2_REG |= TIM2_PRESCALER;
	
	OCR2_REG = 0;
}

void TIM2_CTCinit(void) {
	// Set Timer2 to CTC mode (WGM21 = 1, WGM20 = 0)
	CLR_BIT(TCCR2_REG, 6);
	SET_BIT(TCCR2_REG, 3);

	// Set Prescaler to 256
	TCCR2_REG &= 0b11111000;
	TCCR2_REG |= TIM2_PRESCALER;

	// Set OCR2 for 1 ms delay
	OCR2_REG = 62;
}

void TIM2_voidDelayms(u16 tim2_delay_ms) {
	
	for (u16 i = 0; i < tim2_delay_ms; i++) {
		// Wait until OCF2 flag is set
		while (GET_BIT(TIFR_REG, 7) == 0);
		
		// Clear OCF2 flag by writing logic '1'
		SET_BIT(TIFR_REG, 7);
	}
}


void TIM2_voidServoSetDegree(u16 copy_u16degree){
	OCR2_REG = 33 + (copy_u16degree * (158 - 33)) / 180;
}

void TIM2_voidInitCTC_OV(u8 copy_u8mode) {
	/* Set prescaler */
	TCCR2_REG &= 0b11111000;  // Clear prescaler bits
	TCCR2_REG |= TIM2_PRESCALER;

	if (copy_u8mode == OV_MODE) {
		/* Normal Mode: Clear WGM21 and WGM20 */
		CLR_BIT(TCCR2_REG, 3);
		CLR_BIT(TCCR2_REG, 6);

		/* Enable Timer2 Overflow Interrupt */
		SET_BIT(TIMSK_REG, 6);
		} 
		else if (copy_u8mode == CTC_MODE) {
		/* CTC Mode: Set WGM21, Clear WGM20 */
		SET_BIT(TCCR2_REG, 3);
		CLR_BIT(TCCR2_REG, 6);

		/* Set OCR2 Value */
		OCR2_REG = 62;
	}
}

void TIM2_voidReset(void) {
	TCNT2_REG = 0;  // Reset Timer Counter
}

void TIM2_voidStart(void) {
	/* Reapply the prescaler to start the timer */
	TCCR2_REG &= 0b11111000;  // Clear prescaler bits
	TCCR2_REG |= TIM2_PRESCALER;
}

void TIM2_voidStop(void) {
	/* Clear prescaler to stop the timer */
	TCCR2_REG &= 0b11111000;
}

s16 TIM2_s16ReadVal(void) {
	/* Return the current value of Timer2 counter */
	return TCNT2_REG;
}