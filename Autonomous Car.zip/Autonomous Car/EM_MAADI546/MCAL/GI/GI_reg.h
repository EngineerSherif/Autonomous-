#ifndef _GI_REG_H_ 
#define _GI_REG_H_


#define SREG_REG      *((volatile u8*)0x5F) 





#endif 