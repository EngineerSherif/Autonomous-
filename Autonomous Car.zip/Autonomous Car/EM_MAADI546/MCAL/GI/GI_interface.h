#ifndef _GI_INTERFACE_H_
#define _GI_INTERFACE_H_


void GI_voidEnable(void) ; 

void GI_voidDisable(void) ; 



#endif 