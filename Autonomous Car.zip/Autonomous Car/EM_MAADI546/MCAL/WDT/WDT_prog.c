#include "../../LIB/BIT_MATH.h"
#include "../../LIB/STD_TYPE.h"
#include "WDT_reg.h"
#include "WDT_interface.h"



void WDT_voidEnable(u8 copy_u8time){
	SET_BIT(WDTCR_REG, 3);
	
	WDTCR_REG &= 0x11111000;
	WDTCR_REG |= copy_u8time;
}
void WDT_voidDisable(){
	WDTCR_REG |= 1<<3 | 1<<4;
	WDTCR_REG - 0x00;
}