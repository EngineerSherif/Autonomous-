#ifndef WDT_INTERFACE_H_
#define WDT_INTERFACE_H_

#define time_16_3_ms    0x00
#define time_32_5_ms    0x01
#define time_65_0_ms    0x02
#define time_0_13_s     0x03
#define time_0_26_s     0x04
#define time_0_52_s     0x05
#define time_1_00_s     0x06
#define time_2_10_ms    0x07


void WDT_voidEnable(u8 copy_u8time);
void WDT_voidDisable();


#endif /* WDT_INTERFACE_H_ */