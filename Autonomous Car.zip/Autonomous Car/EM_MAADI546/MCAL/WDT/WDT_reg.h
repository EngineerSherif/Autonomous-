#ifndef WDT_REG_H_
#define WDT_REG_H_


#define WDTCR_REG  *((volatile u8*)0x41)




#endif /* WDT_REG_H_ */