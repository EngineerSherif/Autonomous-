#include "../../LIB/BIT_MATH.h"
#include "../../LIB/STD_TYPE.h"
#include "TIM1_reg.h"
#include "TIM1_interface.h"

void TIM1_voidFastPWM10BitRes(u8 copy_u8pin, u8 copy_u8duty){
	/* Select Mode: 10-bit Fast PWM Mode */
	SET_BIT(TCCR1A_REG, 0);
	SET_BIT(TCCR1A_REG, 1);
	SET_BIT(TCCR1B_REG, 3);
	CLR_BIT(TCCR1B_REG, 4);
	
	TCCR1B_REG &= 0b11111000 ;
	TCCR1B_REG |= TIM1_PRESCALER ;
	
	switch(copy_u8pin){
		case OC1A_PIN: 
		/* select fast PWM mode: non inverting */
			CLR_BIT(TCCR1A_REG, 6);
			SET_BIT(TCCR1A_REG, 7);
			OCR1A_REG = copy_u8duty * 10.24;
			break;
			
		case OC1B_PIN: 
		/* select fast PWM mode: non inverting */
			CLR_BIT(TCCR1A_REG, 4);
			SET_BIT(TCCR1A_REG, 5);
			OCR1B_REG = copy_u8duty * 10.24;
			break;
	}
}

void TIM1_voidFastPWMICR1(void){
	/* Select Mode: Fast PWM ICR Mode */
	CLR_BIT(TCCR1A_REG, 0);
	SET_BIT(TCCR1A_REG, 1);
	SET_BIT(TCCR1B_REG, 3);
	SET_BIT(TCCR1B_REG, 4);
	
	TCCR1B_REG &= 0b11111000 ;
	TCCR1B_REG |= TIM1_PRESCALER ;
	
	/* select fast PWM mode: non inverting */
	CLR_BIT(TCCR1A_REG, 4);
	SET_BIT(TCCR1A_REG, 5);
	
	/* Set ICR */
	ICR1_REG = 40000;
}
void TIM1_voidSetOCRval(u16 copy_u16val){
	/* 2000 = 0 degree    4000 = 180 degree */  /* 1000 = 0 degree   5100 = 180 degree */
	OCR1B_REG = copy_u16val;
}


void TIM1_voidStart(void){
	
	/* normal mode */
	CLR_BIT(TCCR1A_REG,0) ;
	CLR_BIT(TCCR1A_REG,1) ;
	CLR_BIT(TCCR1B_REG,3) ;
	CLR_BIT(TCCR1B_REG,4) ;
	/* SET prescaler */
	/*  TICK = 8/16 =  */
	TCCR1B_REG&=0b11111000 ;
	TCCR1B_REG|=TIM1_PRESCALER ;
}

void TIM1_voidReset(void){
	
	TCNT1_REG=0x0000 ;
}

void TIM1_voidStop(void){
	TCCR1B_REG &= 0;
}

s16 TIM1_s16ReadVal(void) {
	
	return TCNT1_REG ;
}


void TIM1_voidServoSetDegree(u16 copy_u16degree){
	OCR1B_REG = (copy_u16degree * 22.7) + 1000;	
}