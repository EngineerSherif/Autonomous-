#ifndef TIM1_INTERFACE_H_
#define TIM1_INTERFACE_H_

/* Prescalers */
#define  NO_PRESCALER      0x01
#define  _8_PRESCALER      0x02
#define  _32_PRESCALER     0x03
#define  _64_PRESCALER     0x04
#define  _128_PRESCALER    0x05
#define  _256_PRESCALER    0x06
#define  _1024_PRESCALER   0x07

#define  TIM1_PRESCALER      _32_PRESCALER

#define OC1A_PIN   0
#define OC1B_PIN   1

void TIM1_voidFastPWM10BitRes(u8 copy_u8pin, u8 copy_u8duty);
void TIM1_voidFastPWMICR1(void);
void TIM1_voidSetOCRval(u16 copy_u16val);
void TIM1_voidServoSetDegree(u16 copy_u16degree);
void TIM1_voidStart(void);
void TIM1_voidReset(void);
void TIM1_voidStop(void);
s16 TIM1_s16ReadVal(void);


#endif /* TIM1_INTERFACE_H_ */