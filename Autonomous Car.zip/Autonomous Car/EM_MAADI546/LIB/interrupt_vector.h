/*
 * interrupt_vector.h
 *
 * Created: 8/30/2024 4:33:27 PM
 *  Author: Sherif
 */ 


#ifndef INTERRUPT_VECTOR_H_
#define INTERRUPT_VECTOR_H_

#define ISR(__vector_num)      void __vector_num(void)__attribute__((signal));\
                               void __vector_num(void)


#define INT_0   __vector_1
#define INT_1   __vector_2
#define INT_2   __vector_3

#define TIMER0_COMP   __vector_10
#define TIMER0_OVF    __vector_11

#define TIMER2_COMP    __vector_4
#define TIMER2_OVF     __vector_5

#endif /* INTERRUPT_VECTOR_H_ */