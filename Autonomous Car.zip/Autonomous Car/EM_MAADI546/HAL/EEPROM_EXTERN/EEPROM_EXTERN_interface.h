#ifndef EEPROM_EXTERN_INTERFACE_H_
#define EEPROM_EXTERN_INTERFACE_H_


void EEPROM_EXT_voidSendData(u16 copy_u16address, u8 copy_u8data);
u8 EEPROM_EXT_voidRecieveData(u16 copy_u16address);



#endif /* EEPROM_EXTERN_INTERFACE_H_ */