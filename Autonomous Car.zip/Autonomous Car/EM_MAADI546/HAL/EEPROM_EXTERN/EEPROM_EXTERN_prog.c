#include "../../LIB/BIT_MATH.h"
#include "../../LIB/STD_TYPE.h"
#include "../../MCAL/TWI/TWI_interface.h"
#include "EEPROM_EXTERN_interface.h"
#define F_CPU 16000000UL
#include <util/delay.h>


void EEPROM_EXT_voidSendData(u16 copy_u16address, u8 copy_u8data){
	
	u8 LOC_u8DeviceAddress = 0b1010000 | copy_u16address >> 8;
	u8 LOC_u8WordAddress = (u8)copy_u16address;
	TWI_voidMasterInit(copy_u8data);
	TWI_TWI_statusStartCondition();
	TWI_TWI_statusSendSlaveAdressWithWrite(LOC_u8DeviceAddress);
	TWI_TWI_statusMasterSendData(LOC_u8WordAddress);
	TWI_TWI_statusMasterSendData(copy_u8data);
	TWI_voidStopCondition();
	_delay_ms(5);
	
}
u8 EEPROM_EXT_voidRecieveData(u16 copy_u16address){
	u8 LOC_u8data = 0;
	u8 LOC_u8DeviceAddress = 0b1010000 | copy_u16address >> 8;
	u8 LOC_u8WordAddress = (u8)copy_u16address;
	TWI_TWI_statusStartCondition();
	TWI_TWI_statusSendSlaveAdressWithWrite(LOC_u8DeviceAddress);
	TWI_TWI_statusMasterSendData(LOC_u8WordAddress);
	TWI_TWI_statusRepeatedStart();
	TWI_TWI_statusSendSlaveAdressWithRead(LOC_u8DeviceAddress);
	TWI_TWI_statusMasterReciveData(&LOC_u8data);
	TWI_voidStopCondition();
	return LOC_u8data;
}
