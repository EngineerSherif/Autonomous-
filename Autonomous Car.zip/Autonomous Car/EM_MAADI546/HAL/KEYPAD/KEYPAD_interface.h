/*
 * KEYPAD_interface.h
 *
 * Created: 8/23/2024 2:57:50 PM
 *  Author: AMIT
 */ 


#ifndef KEYPAD_INTERFACE_H_
#define KEYPAD_INTERFACE_H_



void KEYPAD_voidInit(void) ; 

u8 KEYPAD_u8GetKey(void) ; 



#endif /* KEYPAD_INTERFACE_H_ */