/*
 * DC_MOTOR_interface.h
 *
 * Created: 9/13/2024 2:41:21 PM
 *  Author: AMIT
 */ 


#ifndef DC_MOTOR_INTERFACE_H_
#define DC_MOTOR_INTERFACE_H_



void DCMOTOR_voidForward(u8 copy_u8dc) ; 
void DCMOTOR_voidReverse(u8 copy_u8dc) ;
void DCMOTOR_voidRight(u8 copy_u8dc);
void DCMOTOR_voidLeft(u8 copy_u8dc);
void DCMOTOR_voidStop() ;







#endif /* DC_MOTOR_INTERFACE_H_ */