/*
 * DC_MOTOR_prog.c
 *
 * Created: 9/13/2024 2:42:08 PM
 *  Author: AMIT
 */ 

#include "../../LIB/BIT_MATH.h"
#include "../../LIB/STD_TYPE.h"
#include "../../MCAL/DIO/DIO_interface.h" 
#include "../../MCAL/TIM1/TIM1_interface.h"
#include "DC_MOTOR_config.h"


void DCMOTOR_voidForward(u8 copy_u8dc) {
	
	  /* set pins direction */
	  
	  DIO_voidSetPinDir(H_EN1_PORT,H_EN1_PIN,OUTPUT) ;
	  DIO_voidSetPinDir(H_EN2_PORT,H_EN2_PIN,OUTPUT) ;
	  DIO_voidSetPinDir(H_A1_PORT,H_A1_PIN,OUTPUT) ;
	  DIO_voidSetPinDir(H_A2_PORT,H_A2_PIN,OUTPUT) ;
	  DIO_voidSetPinDir(H_A3_PORT,H_A3_PIN,OUTPUT) ;
	  DIO_voidSetPinDir(H_A4_PORT,H_A4_PIN,OUTPUT) ;
	  
	  
	  /* set speed*/
	 TIM1_voidFastPWM10BitRes(OC1A_PIN, copy_u8dc);
	  TIM1_voidFastPWM10BitRes(OC1B_PIN, copy_u8dc) ;   
	  
	  /* set motion direction */
	  DIO_voidSetPinVal(H_A1_PORT,H_A1_PIN,HIGH) ; 
	  DIO_voidSetPinVal(H_A2_PORT,H_A2_PIN,LOW) ;
	  DIO_voidSetPinVal(H_A3_PORT,H_A3_PIN,HIGH) ;
	  DIO_voidSetPinVal(H_A4_PORT,H_A4_PIN,LOW) ;
	
}

void DCMOTOR_voidRight(u8 copy_u8dc) {
	
	
	 DIO_voidSetPinDir(H_EN1_PORT,H_EN1_PIN,OUTPUT) ;
	 DIO_voidSetPinDir(H_EN2_PORT,H_EN2_PIN,OUTPUT) ;
	 DIO_voidSetPinDir(H_A1_PORT,H_A1_PIN,OUTPUT) ;
	 DIO_voidSetPinDir(H_A2_PORT,H_A2_PIN,OUTPUT) ;
	 DIO_voidSetPinDir(H_A3_PORT,H_A3_PIN,OUTPUT) ;
	 DIO_voidSetPinDir(H_A4_PORT,H_A4_PIN,OUTPUT) ;
	 
	 
	 /* set speed*/
	 TIM1_voidFastPWM10BitRes(OC1A_PIN, copy_u8dc);
	 TIM1_voidFastPWM10BitRes(OC1B_PIN, copy_u8dc) ;
	 
	 /* set motion direction */
	 DIO_voidSetPinVal(H_A1_PORT,H_A1_PIN,HIGH) ;
	 DIO_voidSetPinVal(H_A2_PORT,H_A2_PIN,LOW) ;
	 DIO_voidSetPinVal(H_A3_PORT,H_A3_PIN,LOW) ;
	 DIO_voidSetPinVal(H_A4_PORT,H_A4_PIN,LOW) ;
	 
}

void DCMOTOR_voidLeft(u8 copy_u8dc) {
	
	
	DIO_voidSetPinDir(H_EN1_PORT,H_EN1_PIN,OUTPUT) ;
	DIO_voidSetPinDir(H_EN2_PORT,H_EN2_PIN,OUTPUT) ;
	DIO_voidSetPinDir(H_A1_PORT,H_A1_PIN,OUTPUT) ;
	DIO_voidSetPinDir(H_A2_PORT,H_A2_PIN,OUTPUT) ;
	DIO_voidSetPinDir(H_A3_PORT,H_A3_PIN,OUTPUT) ;
	DIO_voidSetPinDir(H_A4_PORT,H_A4_PIN,OUTPUT) ;
	
	
	/* set speed*/
	TIM1_voidFastPWM10BitRes(OC1A_PIN, copy_u8dc);
	TIM1_voidFastPWM10BitRes(OC1B_PIN, copy_u8dc) ;
	
	/* set motion direction */
	DIO_voidSetPinVal(H_A1_PORT,H_A1_PIN,LOW) ;
	DIO_voidSetPinVal(H_A2_PORT,H_A2_PIN,LOW) ;
	DIO_voidSetPinVal(H_A3_PORT,H_A3_PIN,HIGH) ;
	DIO_voidSetPinVal(H_A4_PORT,H_A4_PIN,LOW) ;
	
}

void DCMOTOR_voidReverse(u8 copy_u8dc) {
	
	/* set pins direction */
	
	DIO_voidSetPinDir(H_EN1_PORT,H_EN1_PIN,OUTPUT) ;
	DIO_voidSetPinDir(H_EN2_PORT,H_EN2_PIN,OUTPUT) ;
	DIO_voidSetPinDir(H_A1_PORT,H_A1_PIN,OUTPUT) ;
	DIO_voidSetPinDir(H_A2_PORT,H_A2_PIN,OUTPUT) ;
	DIO_voidSetPinDir(H_A3_PORT,H_A3_PIN,OUTPUT) ;
	DIO_voidSetPinDir(H_A4_PORT,H_A4_PIN,OUTPUT) ;
	
	
	/* set speed*/
	TIM1_voidFastPWM10BitRes(OC1A_PIN, copy_u8dc);
	TIM1_voidFastPWM10BitRes(OC1B_PIN, copy_u8dc) ;
	
	/* set motion direction */
	DIO_voidSetPinVal(H_A1_PORT,H_A1_PIN,LOW) ;
	DIO_voidSetPinVal(H_A2_PORT,H_A2_PIN,HIGH) ;
	DIO_voidSetPinVal(H_A3_PORT,H_A3_PIN,LOW) ;
	DIO_voidSetPinVal(H_A4_PORT,H_A4_PIN,HIGH) ;
	
}

void DCMOTOR_voidStop(){
	
	/* set pins dir */
	
	DIO_voidSetPinDir(H_EN1_PORT,H_EN1_PIN,OUTPUT) ;
	DIO_voidSetPinDir(H_EN2_PORT,H_EN2_PIN,OUTPUT) ;
	DIO_voidSetPinDir(H_A1_PORT,H_A1_PIN,OUTPUT) ;
	DIO_voidSetPinDir(H_A2_PORT,H_A2_PIN,OUTPUT) ;
	DIO_voidSetPinDir(H_A3_PORT,H_A3_PIN,OUTPUT) ;
	DIO_voidSetPinDir(H_A4_PORT,H_A4_PIN,OUTPUT) ;
	
	
	DIO_voidSetPinVal(H_A1_PORT,H_A1_PIN,LOW) ;
	DIO_voidSetPinVal(H_A2_PORT,H_A2_PIN,LOW) ;
	DIO_voidSetPinVal(H_A3_PORT,H_A3_PIN,LOW) ;
	DIO_voidSetPinVal(H_A3_PORT,H_A3_PIN,LOW) ;
	
}